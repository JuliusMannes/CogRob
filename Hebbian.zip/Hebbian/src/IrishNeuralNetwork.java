
public class IrishNeuralNetwork extends NeuralNetwork {
	private String[] m_aOutputLabels = null;
	
	@Override
	void Init(int a_iHiddenLayerSize) {
		//Create the four input neurons
		for(int i=0; i<4;i++) {
			m_aInputLayer.add(new Neuron());		
		}
		//Create the hidden layer (spooky)
		for(int i=0; i<a_iHiddenLayerSize; i++) {
			Neuron pNeuron = new Neuron();
			m_aHiddenLayer.add(pNeuron);
			//Create the first synapse layer between input and hidden layer
			for(int k=0; k<4; k++) {
				new Synapse(m_aInputLayer.get(k), pNeuron);
			}
		}
		//Create the output layer
		for(int i=0; i<3; i++) {
			Neuron pNeuron = new Neuron();
			m_aOutputLayer.add(pNeuron);
			//Create the last layer of synapses.
			for(int k=0; k<a_iHiddenLayerSize; k++) {
				new Synapse(m_aHiddenLayer.get(k), pNeuron);
			}
		}
		
		//Create the output labels
		m_aOutputLabels = new String[3];
		m_aOutputLabels[0] = "Iris-setosa";
		m_aOutputLabels[1] = "Iris-versicolor";
		m_aOutputLabels[2] = "Iris-virginica";
	}

	@Override
	void ReceiveInput(DataPoint a_pInputData) {
		//Convert the data
		IrisDataPoint pInputData = (IrisDataPoint)a_pInputData;
		m_aInputLayer.get(0).ReceiveInput(pInputData.m_fSepalLength);		
		m_aInputLayer.get(1).ReceiveInput(pInputData.m_fSepalWidth);
		m_aInputLayer.get(2).ReceiveInput(pInputData.m_fPetalLength);
		m_aInputLayer.get(3).ReceiveInput(pInputData.m_fPetalWidth);
	}

	@Override
	public void Check(DataPoint a_pInputData) {
		//Determine the winner
		int WinnerId = 0;
		for(int i=1; i<3;i++) {
			if(m_aOutputLayer.get(i).GetValue() > m_aOutputLayer.get(WinnerId).GetValue()) {
				WinnerId = i;
			}
		}
		
		//Check for success
		IrisDataPoint pInputData = (IrisDataPoint)a_pInputData;
		if(pInputData.m_sSpecies == m_aOutputLabels[WinnerId]) {
			//Right
			System.out.println("The target was right: "+m_aOutputLabels[WinnerId]);
		}else {
			//Wrong
			System.out.println("The target was wrong, guessed: "+m_aOutputLabels[WinnerId]+" actual: "+pInputData.m_sSpecies);
		}
	}
}
