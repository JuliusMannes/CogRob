import java.util.ArrayList;


public abstract class NeuralNetwork {
	
	protected ArrayList<Neuron> m_aInputLayer = null;
	protected ArrayList<Neuron> m_aHiddenLayer = null;
	protected ArrayList<Neuron> m_aOutputLayer = null;
	
	public NeuralNetwork() {
		m_aInputLayer = new ArrayList<Neuron>();
		m_aHiddenLayer = new ArrayList<Neuron>();
		m_aOutputLayer = new ArrayList<Neuron>();
	}
	
	abstract void Init(int a_iHiddenLayerSize);
	
	public void Reset() {
		for(int i=0; i<m_aInputLayer.size(); i++) {
			m_aInputLayer.get(i).Reset();
		}
		for(int i=0; i<m_aHiddenLayer.size(); i++) {
			m_aHiddenLayer.get(i).Reset();
		}
		for(int i=0; i<m_aOutputLayer.size(); i++) {
			m_aOutputLayer.get(i).Reset();
		}
	}
	
	public void Run(DataPoint a_pInputData) {
		//Reset the network first
		Reset();
		
		//Process the input
		ReceiveInput(a_pInputData);
		
		//Fire the input layer
		for(int i=0; i < m_aInputLayer.size(); i++) {
			m_aInputLayer.get(i).Fire();
		}
		
		//Fire the hidden layer
		for(int i=0; i < m_aHiddenLayer.size(); i++) {
			m_aHiddenLayer.get(i).Fire();
		}
	}
	
	abstract void ReceiveInput(DataPoint a_pInputData);
	abstract public void Check(DataPoint a_pInputData);
}
