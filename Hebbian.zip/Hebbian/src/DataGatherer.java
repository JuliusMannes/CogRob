
abstract public class DataGatherer {
	
	//Functions
	public abstract void Init();
	public abstract float[] GetDataPoint();
	public abstract void PrintData();
}
