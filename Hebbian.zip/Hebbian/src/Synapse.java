
public class Synapse {
	//Variables
	private Neuron m_pInputNeuron = null;
	private Neuron m_pOutputNeuron = null;
	private float m_fWeight = 0.0f;
	private float m_fLastFiredValue = 0.0f;
	
	public Synapse(Neuron a_pInputNeuron, Neuron a_pOutNeuron) {
		m_pInputNeuron = a_pInputNeuron;
		m_pOutputNeuron = a_pOutNeuron;
		m_fWeight = (float) (Math.random() * 2.0f - 1.0f);
		m_pInputNeuron.AddOutputSynapse(this);
		m_pOutputNeuron.AddInputSynapse(this);
	}
	
	public void Propagates(float a_fValue) {
		m_fLastFiredValue = a_fValue * m_fWeight;
		m_pOutputNeuron.ReceiveInput(m_fLastFiredValue);
	}
	
	public void Reset() {
		m_fLastFiredValue = 0.0f;
	}
}
