

public class Main {
	public static void main(String[] args) {
		//Get the datagatherer
		DataGatherer pDataGatherer = new IrisDataGatherer();
		pDataGatherer.Init();
		pDataGatherer.PrintData();
		
		IrishNeuralNetwork pNetwork = new IrishNeuralNetwork();
		pNetwork.Init(8);
		
		//Loop it for all data point, because fuck it
		for(int i=0; i < 150; i++) {
			//pNetwork.ReceiveInput(pDataGatherer.GetDataPoint())
		}
	}
}
