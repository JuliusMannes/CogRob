import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class IrisDataGatherer extends DataGatherer {
	private ArrayList<IrisDataPoint> m_pDataSet = null; 

	@Override
	public void Init() {
		//Variables
		m_pDataSet = new ArrayList<IrisDataPoint>();
		BufferedReader BuffReader = null;
		String Line = "";
		
		try {
			//Try and open the file
			BuffReader = new BufferedReader(new FileReader("IRIS.csv"));
			//Read the lines
			while((Line = BuffReader.readLine()) != null) {
				//Separate by comma
				String[] VariablesData = Line.split(",");
				IrisDataPoint DataPoint = new IrisDataPoint();
				DataPoint.m_fSepalLength = Float.parseFloat(VariablesData[0]);
				DataPoint.m_fSepalWidth = Float.parseFloat(VariablesData[1]);
				DataPoint.m_fPetalLength = Float.parseFloat(VariablesData[2]);
				DataPoint.m_fPetalWidth = Float.parseFloat(VariablesData[3]);
				DataPoint.m_sSpecies = VariablesData[4];
				m_pDataSet.add(DataPoint);
			}
		} catch(FileNotFoundException e){
			System.out.println("File not found");
			e.printStackTrace();
		} catch (IOException e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public float[] GetDataPoint() {
		//Math.
		return null;
	}
	
	public void PrintData() {
		for(int i=0; i < m_pDataSet.size(); i++) {
			System.out.println(m_pDataSet.get(i).m_fSepalLength);
			System.out.println(m_pDataSet.get(i).m_fSepalWidth);
			System.out.println(m_pDataSet.get(i).m_fPetalLength);
			System.out.println(m_pDataSet.get(i).m_fPetalWidth);
			System.out.println(m_pDataSet.get(i).m_sSpecies);
		}
	}
}
