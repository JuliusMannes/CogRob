
public class hebDataGatherer extends DataGatherer {

	private hebDataPoint DataPoint = null;
	private UltraSonicSensor USS_Left = null;
	private UltraSonicSensor USS_Right = null;
	private TouchSensor TS_Left = null;
	private TouchSensor TS_Right = null;
	
	
	public void Init(UltraSonicSensor left, UltraSonicSensor right, TouchSensor left1, TouchSensor right1) {
		DataPoint = new hebDataPoint();
		USS_Left = left;
		USS_Right = right;
		TS_Left = left1;
		TS_Right = right1;
	}

	@Override
	public hebDataPoint GetDataPoint() {
		// TODO Auto-generated method stub
		DataPoint.distance = USS_Left.DetectSample();
		DataPoint.touched = TS_Left.DetectSample();
		DataPoint.distance1 = USS_Right.DetectSample();
		DataPoint.touched1 = TS_Right.DetectSample();
		
		DataPoint.distance = 1.0f - DataPoint.distance / 0.3f;
		DataPoint.distance = (Float.isInfinite(DataPoint.distance))?0.0f:DataPoint.distance;
		DataPoint.distance1 = 1.0f - DataPoint.distance1 / 0.3f;
		DataPoint.distance1 = (Float.isInfinite(DataPoint.distance1))?0.0f:DataPoint.distance1;
		return DataPoint;
	}

	@Override
	public void PrintData() {
		System.out.println(DataPoint.distance);
		System.out.println(DataPoint.touched);
		System.out.println(DataPoint.distance1);
		System.out.println(DataPoint.touched);
		
	}
}
