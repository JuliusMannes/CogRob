import java.util.ArrayList;

import lejos.hardware.motor.Motor;
import lejos.hardware.motor.NXTRegulatedMotor;

public class hebbianNeuralNetwork extends NeuralNetwork {

	private String[] m_aOutputLabels = null;
	private NXTRegulatedMotor m_pLeftWheel = null;
	private NXTRegulatedMotor m_pRightWheel = null;
	
	@Override
	void Init(int a_iHiddenLayerSize) {
		// Create the four input neurons
		for (int i = 0; i < 2; i++) {
			m_aInputLayer.add(new Neuron());
		}
		// Create the output layer
		for (int i = 0; i < 2; i++) {
			Neuron pNeuron = new Neuron();
			m_aOutputLayer.add(pNeuron);
			// Create the last layer of synapses.
			for (int k = 0; k < m_aInputLayer.size(); k++) {
				new Synapse(m_aInputLayer.get(k), pNeuron);
			}
		}
	}
	
	public void SetMotors(NXTRegulatedMotor Left, NXTRegulatedMotor Right) {
		m_pLeftWheel = Left;
		m_pRightWheel = Right;
	}

	@Override
	protected void ReceiveInput(DataPoint a_pInputData) {
		// Convert the data
		hebDataPoint pInputData = (hebDataPoint) a_pInputData;
		m_aInputLayer.get(0).ReceiveInput(pInputData.distance);
		m_aInputLayer.get(1).ReceiveInput(pInputData.distance1);
	}

	@Override
	public void Check(DataPoint a_pInputData) {
		hebDataPoint Data = (hebDataPoint)a_pInputData;
		boolean LeftTouch = false;
		boolean RightTouch = false;
		m_pLeftWheel.setSpeed((int)(m_aOutputLayer.get(0).GetValue() * 180));
		if(Data.touched > 0.1){
			m_pLeftWheel.setSpeed(0);	
			LeftTouch = true;
		}

		m_pRightWheel.setSpeed((int)(m_aOutputLayer.get(1).GetValue() * 180));
		if(Data.touched1 > 0.1){
			m_pRightWheel.setSpeed(0);	
			RightTouch = true;
		}
		
		//Set motors
		if(LeftTouch) {
			m_aOutputLayer.get(0).GetInputSynapses().get(0).Learn(100);
			m_pRightWheel.setSpeed(180);
			m_pRightWheel.forward();
		} else {
			m_pRightWheel.backward();
		}
		
		if(RightTouch) {
			m_aOutputLayer.get(1).GetInputSynapses().get(1).Learn(100);
			m_pLeftWheel.setSpeed(180);
			m_pLeftWheel.forward();
		} else {
			m_pLeftWheel.backward();
		}
	}

	@Override
	public void Learn(DataPoint a_pInputData) {
		hebDataPoint Data = (hebDataPoint)a_pInputData;
		System.out.println("Left: "+Data.distance);
		System.out.println("Right: "+Data.distance1);
		for (int k = 0; k < m_aOutputLayer.size(); k++) {
			m_aOutputLayer.get(k).GetInputSynapses().get(0).Learn(Data.distance);
			m_aOutputLayer.get(k).GetInputSynapses().get(1).Learn(Data.distance1);
		}
	}
}
