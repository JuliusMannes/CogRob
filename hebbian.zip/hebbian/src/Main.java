

public class Main {
	public static void main(String[] args) {
		//Get the datagatherer
		DataGatherer pDataGatherer = new IrisDataGatherer();
		pDataGatherer.Init();
		
		IrishNeuralNetwork pNetwork = new IrishNeuralNetwork();
		pNetwork.Init(8);
		pNetwork.PrintSynapticValues();
		//Loop it for all data point, because fuck it
		for(int i=0; i < 120; i++) {
			DataPoint CurrentData = pDataGatherer.GetDataPoint();
			pNetwork.Run(CurrentData);
			pNetwork.Learn(CurrentData);
			//pNetwork.NormalizeNetwork();
		}
		
		for(int i=0; i < 30; i++) {
			DataPoint CurrentData = pDataGatherer.GetDataPoint();
			pNetwork.Run(CurrentData);
			pNetwork.Check(CurrentData);
		}
		
		pNetwork.PrintSynapticValues();
	}
}
