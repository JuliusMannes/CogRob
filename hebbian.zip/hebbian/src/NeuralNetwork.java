import java.util.ArrayList;


public abstract class NeuralNetwork {
	
	protected ArrayList<Neuron> m_aInputLayer = null;
	protected ArrayList<Neuron> m_aHiddenLayer = null;
	protected ArrayList<Neuron> m_aOutputLayer = null;
	protected int m_iCorrectGuesses = 0;
	protected int m_iIncorrectGuesses = 0;
	
	public NeuralNetwork() {
		m_aInputLayer = new ArrayList<Neuron>();
		m_aHiddenLayer = new ArrayList<Neuron>();
		m_aOutputLayer = new ArrayList<Neuron>();
	}
	
	abstract void Init(int a_iHiddenLayerSize);
	
	public void Reset() {
		for(int i=0; i<m_aInputLayer.size(); i++) {
			m_aInputLayer.get(i).Reset();
		}
		for(int i=0; i<m_aHiddenLayer.size(); i++) {
			m_aHiddenLayer.get(i).Reset();
		}
		for(int i=0; i<m_aOutputLayer.size(); i++) {
			m_aOutputLayer.get(i).Reset();
		}
	}
	
	public void Run(DataPoint a_pInputData) {
		//Reset the network first
		Reset();
		
		//Process the input
		ReceiveInput(a_pInputData);
		
		//Fire the input layer
		for(int i=0; i < m_aInputLayer.size(); i++) {
			m_aInputLayer.get(i).Fire();
		}
		
		//Fire the hidden layer
		for(int i=0; i < m_aHiddenLayer.size(); i++) {
			m_aHiddenLayer.get(i).Fire();
		}
	}
	
	public void NormalizeNetwork() {
		//float Min = 0.0f;
		//float Max = 0.0f;
		//Get the max synapses
		for(int i=0; i < m_aInputLayer.size(); i++) {
			float Max = 0.0f;
			float Min = 0.0f;
			ArrayList<Synapse> Synapses = m_aInputLayer.get(i).GetOutSynapses();
			for(int k=0; k < Synapses.size(); k++) {
				Min = Math.min(Synapses.get(k).GetWeight(), Min);
				Max = Math.max(Synapses.get(k).GetWeight(), Max);
			}
			for(int k=0; k < Synapses.size(); k++) {
				if(Synapses.get(k).GetWeight() >= 0.0f) {
					Synapses.get(k).SetWeight(Synapses.get(k).GetWeight() / Max);
				}else {
					Synapses.get(k).SetWeight(Synapses.get(k).GetWeight() / Min);
				}
			}
		}
		for(int i=0; i < m_aHiddenLayer.size(); i++) {
			float Max = 0.0f;
			float Min = 0.0f;
			ArrayList<Synapse> Synapses = m_aHiddenLayer.get(i).GetOutSynapses();
			for(int k=0; k < Synapses.size(); k++) {
				Min = Math.min(Synapses.get(k).GetWeight(), Min);
				Max = Math.max(Synapses.get(k).GetWeight(), Max);
			}
			for(int k=0; k < Synapses.size(); k++) {
				if(Synapses.get(k).GetWeight() >= 0.0f) {
					Synapses.get(k).SetWeight(Synapses.get(k).GetWeight() / Max);
				}else {
					Synapses.get(k).SetWeight(Synapses.get(k).GetWeight() / -Min);
				}
			}
		}		
		//Set all weights
		/*
		for(int i=0; i < m_aInputLayer.size(); i++) {
			ArrayList<Synapse> Synapses = m_aInputLayer.get(i).GetOutSynapses();
			for(int k=0; k < Synapses.size(); k++) {
				float Weight = Synapses.get(k).GetWeight();
				if(Weight >= 0.0f) {
					Synapses.get(k).SetWeight(Weight / Max);
				} else {
					Synapses.get(k).SetWeight(Weight / -Min);
				}
				
			}
		}
		for(int i=0; i < m_aHiddenLayer.size(); i++) {
			ArrayList<Synapse> Synapses = m_aHiddenLayer.get(i).GetOutSynapses();
			for(int k=0; k < Synapses.size(); k++) {
				float Weight = Synapses.get(k).GetWeight();
				if(Weight >= 0.0f) {
					Synapses.get(k).SetWeight(Weight / Max);
				} else {
					Synapses.get(k).SetWeight(Weight / -Min);
				}
			}
		}*/
	}
	
	public void PrintSynapticValues() {
		//Create data array
		final float[][] table = new float[m_aInputLayer.size()][m_aHiddenLayer.size()];
		
		//Prepare data to print in array
		for(int i=0; i < m_aInputLayer.size(); i++) {
			ArrayList<Synapse> OutputSynapses = m_aInputLayer.get(i).GetOutSynapses();
			for(int k=0; k < OutputSynapses.size();k++) {
				table[i][k] = OutputSynapses.get(k).GetWeight();
			}
		}
		//Print the data
		for(int k=0; k < m_aHiddenLayer.size(); k++) {
			for(int i=0; i < m_aInputLayer.size(); i++) {
				System.out.format("%-15f", table[i][k]);
			}
			System.out.format("\n");
		}
		
		//Create data array
		final float[][] stable = new float[m_aHiddenLayer.size()][m_aOutputLayer.size()];
				
		//Prepare data to print in array
		for(int i=0; i < m_aHiddenLayer.size(); i++) {
			ArrayList<Synapse> OutputSynapses = m_aHiddenLayer.get(i).GetOutSynapses();
			for(int k=0; k < OutputSynapses.size();k++) {
				stable[i][k] = OutputSynapses.get(k).GetWeight();
			}
		}
		//Print the data
		for(int k=0; k < m_aOutputLayer.size(); k++) {
			for(int i=0; i < m_aHiddenLayer.size(); i++) {
				System.out.format("%-15f", stable[i][k]);
			}
			System.out.format("\n");
		}
		
		//Print correctness
		System.out.format("Correct (Perc): %-15f Incorrect: %-15f", m_iCorrectGuesses/(float)(m_iCorrectGuesses+m_iIncorrectGuesses), m_iIncorrectGuesses/(float)(m_iCorrectGuesses+m_iIncorrectGuesses));
	}
	
	abstract protected void ReceiveInput(DataPoint a_pInputData);
	abstract public void Check(DataPoint a_pInputData);
	abstract public void Learn(DataPoint a_pInputData);
}
