
abstract public class DataGatherer {
	
	//Functions
	public abstract void Init();
	public abstract DataPoint GetDataPoint();
	public abstract void PrintData();
}
