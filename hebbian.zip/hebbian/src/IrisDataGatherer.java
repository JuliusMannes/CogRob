import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class IrisDataGatherer extends DataGatherer {
	private ArrayList<IrisDataPoint> m_pDataSet = null; 
	private int Counter = 0;
	
	@Override
	public void Init() {
		//Variables
		m_pDataSet = new ArrayList<IrisDataPoint>();
		BufferedReader BuffReader = null;
		String Line = "";		
		try {
			//Try and open the file
			BuffReader = new BufferedReader(new FileReader("IRIS.csv"));
			//Read the lines
			while((Line = BuffReader.readLine()) != null) {
				//Separate by comma
				String[] VariablesData = Line.split(",");
				IrisDataPoint DataPoint = new IrisDataPoint();
				DataPoint.m_fSepalLength = Float.parseFloat(VariablesData[0]);
				DataPoint.m_fSepalWidth = Float.parseFloat(VariablesData[1]);
				DataPoint.m_fPetalLength = Float.parseFloat(VariablesData[2]);
				DataPoint.m_fPetalWidth = Float.parseFloat(VariablesData[3]);
				DataPoint.m_sSpecies = VariablesData[4];
				m_pDataSet.add(DataPoint);
			}
		} catch(FileNotFoundException e){
			System.out.println("File not found");
			e.printStackTrace();
		} catch (IOException e) {
            e.printStackTrace();
        }
		float mean_SepalLength = 0, mean_SepalWidth = 0 , mean_PetalLength = 0, mean_PetalWidth = 0;
		float std_SepalLength = 0, std_SepalWidth = 0 , std_PetalLength = 0, std_PetalWidth = 0;
		//Calculate the mean
		for(int i = 0; i < m_pDataSet.size(); i++){
			 mean_SepalLength += m_pDataSet.get(i).m_fSepalLength;
			 mean_SepalWidth += m_pDataSet.get(i).m_fSepalWidth;
			 mean_PetalLength += m_pDataSet.get(i).m_fPetalLength;
			 mean_PetalWidth += m_pDataSet.get(i).m_fPetalWidth;
		}
		mean_SepalLength /= m_pDataSet.size();
		mean_SepalWidth /= m_pDataSet.size();
		mean_PetalLength /= m_pDataSet.size();
		mean_PetalWidth /= m_pDataSet.size();
		
		//Calculate the std dev
		for(int i = 0; i < m_pDataSet.size(); i++){
			std_SepalLength += Math.pow((m_pDataSet.get(i).m_fSepalLength - mean_SepalLength),2);
			std_SepalWidth += Math.pow((m_pDataSet.get(i).m_fSepalWidth - mean_SepalWidth),2);
			std_PetalLength += Math.pow((m_pDataSet.get(i).m_fPetalLength - mean_PetalLength),2);
			std_PetalWidth  += Math.pow((m_pDataSet.get(i).m_fPetalWidth - mean_PetalWidth),2);
		}
		std_SepalLength = (float)Math.sqrt(std_SepalLength /m_pDataSet.size());
		std_SepalWidth = (float)Math.sqrt(std_SepalWidth /m_pDataSet.size());
		std_PetalLength = (float)Math.sqrt(std_PetalLength /m_pDataSet.size());
		std_PetalWidth = (float)Math.sqrt(std_PetalWidth /m_pDataSet.size());
		
		//Normalize the input
		for(int i = 0; i < m_pDataSet.size(); i++){
			//m_pDataSet.get(i).m_fSepalLength = ((m_pDataSet.get(i).m_fSepalLength - mean_SepalLength) / std_SepalLength);
			//m_pDataSet.get(i).m_fSepalWidth = ((m_pDataSet.get(i).m_fSepalWidth - mean_SepalWidth) / std_SepalWidth);
			//m_pDataSet.get(i).m_fPetalLength = ((m_pDataSet.get(i).m_fPetalLength - mean_PetalLength) / std_PetalLength);
			//m_pDataSet.get(i).m_fPetalWidth = ((m_pDataSet.get(i).m_fPetalWidth - mean_PetalWidth) / std_PetalWidth);
		}
		Collections.shuffle(m_pDataSet);
	}

	@Override
	public DataPoint GetDataPoint() {
		//DataPoint ReturnValue = m_pDataSet.get((int)(Math.random() * m_pDataSet.size()));
		DataPoint ReturnValue = m_pDataSet.get(Counter);
		Counter++;
		return ReturnValue;
	}
	
	public void PrintData() {
		for(int i=0; i < m_pDataSet.size(); i++) {
			System.out.println(m_pDataSet.get(i).m_fSepalLength);
			System.out.println(m_pDataSet.get(i).m_fSepalWidth);
			System.out.println(m_pDataSet.get(i).m_fPetalLength);
			System.out.println(m_pDataSet.get(i).m_fPetalWidth);
			System.out.println(m_pDataSet.get(i).m_sSpecies);
		}
	}
}
