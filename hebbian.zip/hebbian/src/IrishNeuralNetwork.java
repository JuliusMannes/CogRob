import java.util.ArrayList;


public class IrishNeuralNetwork extends NeuralNetwork {
	private String[] m_aOutputLabels = null;
	
	@Override
	void Init(int a_iHiddenLayerSize) {
		//Create the four input neurons
		for(int i=0; i<4;i++) {
			m_aInputLayer.add(new Neuron());		
		}
		//Create the hidden layer (spooky)
		for(int i=0; i<a_iHiddenLayerSize; i++) {
			Neuron pNeuron = new Neuron();
			m_aHiddenLayer.add(pNeuron);
			//Create the first synapse layer between input and hidden layer
			for(int k=0; k<4; k++) {
				new Synapse(m_aInputLayer.get(k), pNeuron);
			}
		}
		//Create the output layer
		for(int i=0; i<3; i++) {
			Neuron pNeuron = new Neuron();
			m_aOutputLayer.add(pNeuron);
			//Create the last layer of synapses.
			for(int k=0; k<a_iHiddenLayerSize; k++) {
				new Synapse(m_aHiddenLayer.get(k), pNeuron);
			}
		}
		
		//Create the output labels
		m_aOutputLabels = new String[3];
		m_aOutputLabels[0] = "Iris-setosa";
		m_aOutputLabels[1] = "Iris-versicolor";
		m_aOutputLabels[2] = "Iris-virginica";
	}

	@Override
	protected void ReceiveInput(DataPoint a_pInputData) {
		//Convert the data
		IrisDataPoint pInputData = (IrisDataPoint)a_pInputData;
		m_aInputLayer.get(0).ReceiveInput(pInputData.m_fSepalLength);		
		m_aInputLayer.get(1).ReceiveInput(pInputData.m_fSepalWidth);
		m_aInputLayer.get(2).ReceiveInput(pInputData.m_fPetalLength);
		m_aInputLayer.get(3).ReceiveInput(pInputData.m_fPetalWidth);
	}

	@Override
	public void Check(DataPoint a_pInputData) {
		//Determine the winner
		int WinnerId = 0;
		for(int i=1; i<3;i++) {
			if(Math.abs(m_aOutputLayer.get(i).GetValue()) > Math.abs(m_aOutputLayer.get(WinnerId).GetValue())) {
				WinnerId = i;
			}
		}
		System.out.println("Values 0: "+m_aOutputLayer.get(0).GetValue()+"; 1: "+m_aOutputLayer.get(1).GetValue()+"; 2: "+m_aOutputLayer.get(2).GetValue());
		
		//Check for success
		IrisDataPoint pInputData = (IrisDataPoint)a_pInputData;
		if(pInputData.m_sSpecies.equals(m_aOutputLabels[WinnerId])) {
			//Right
			System.out.println("The target was right: "+m_aOutputLabels[WinnerId]);
			m_iCorrectGuesses++;
		}else {
			//Wrong
			System.out.println("The target was wrong, guessed: "+m_aOutputLabels[WinnerId]+" actual: "+pInputData.m_sSpecies);
			m_iIncorrectGuesses++;
		}
	}

	@Override
	public void Learn(DataPoint a_pInputData) {
		//The learning rule - Super simple learning rule �Jelle
		//Search for the correct output layer
		int CorrectOutput = 0;
		IrisDataPoint pInputData = (IrisDataPoint)a_pInputData;
		for(int i=0; i<3; i++) {
			if(pInputData.m_sSpecies == m_aOutputLabels[i]) {
				CorrectOutput = i;
				break;
			}
		}
		
		//Go through all the connections
		//for(int i=0; i < m_aOutputLayer.size(); i++) {
		//	m_aOutputLayer.get(i).Learn();
		//}
		for(int k=0; k < m_aOutputLayer.size(); k++) {
			ArrayList<Synapse> InputSynapses = m_aOutputLayer.get(CorrectOutput).GetInputSynapses();
			for(int i=0; i < InputSynapses.size(); i++) {
				InputSynapses.get(i).Learn((k==CorrectOutput)?1:-0.5f);
			}
		}
		
	}
}
