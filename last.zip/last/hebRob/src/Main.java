import lejos.hardware.motor.Motor;
import lejos.hardware.port.SensorPort;

public class Main {
	public static void main(String[] args) {
		// Get the datagatherer

		UltraSonicSensor Left_U = new UltraSonicSensor(SensorPort.S1, 5);
		UltraSonicSensor Right_U = new UltraSonicSensor(SensorPort.S4, 5);
		TouchSensor Left_T = new TouchSensor(SensorPort.S3, 1);
		TouchSensor Right_T = new TouchSensor(SensorPort.S2, 1);
		
		hebDataGatherer pDataGatherer = new hebDataGatherer();
		pDataGatherer.Init(Left_U, Right_U, Left_T, Right_T);
		
		hebbianNeuralNetwork pNetwork = new hebbianNeuralNetwork();
		pNetwork.Init(4);
		pNetwork.SetMotors(Motor.A, Motor.D);
		pNetwork.PrintSynapticValues();
		boolean exit = false;
		while( !exit) {
			hebDataPoint CurrentData = pDataGatherer.GetDataPoint();
			pNetwork.Run(CurrentData);
			pNetwork.Check(CurrentData);
			pNetwork.Learn(CurrentData);

			// pNetwork.NormalizeNetwork();
		}
		pNetwork.PrintSynapticValues();
	}
}
