import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3TouchSensor;
import lejos.hardware.sensor.NXTUltrasonicSensor;

public class TouchSensor extends Sensor {
	public TouchSensor(Port port, int a_pSampleSize){
		Init(a_pSampleSize);
		m_pSensor = new EV3TouchSensor(port); 
	}

	@Override
	protected void UpdateSampleProvider() {
		// TODO Auto-generated method stub
		m_pSampleProvider = ((EV3TouchSensor) m_pSensor).getTouchMode();
	}
}
