
public class hebDataPoint extends DataPoint{
	public float distance = 0.0f;
	public float distance1 = 0.0f;
	public float touched = 0.0f;
	public float touched1 = 0.0f;
}
