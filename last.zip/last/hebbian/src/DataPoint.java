
public abstract class DataPoint {
	public void PrintDataSet() {
		
	}
}
