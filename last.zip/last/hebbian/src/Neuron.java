import java.util.ArrayList;

public class Neuron {
	//Variables
	private float m_fValue = 0.0f;
	private ArrayList<Synapse> m_aInputSynapses = null;
	private ArrayList<Synapse> m_aOutputSynapses = null;
	
	public Neuron() {
		m_fValue = 0.0f;
		m_aInputSynapses = new ArrayList<Synapse>();
		m_aOutputSynapses = new ArrayList<Synapse>();
	}
	
	public void Fire() {
		for(int i=0; i<m_aOutputSynapses.size(); i++) {
			m_aOutputSynapses.get(i).Propagates(m_fValue);
		}
	}
	
	public void ReceiveInput(float a_fInput) {
		m_fValue += a_fInput;
	}
	
	public void Reset() {
		m_fValue = 0.0f;
		//Also reset all synapses
		for(int i=0; i<m_aOutputSynapses.size(); i++) {
			m_aOutputSynapses.get(i).Reset();
		}
	}
	
	public void AddInputSynapse(Synapse a_pSynapse) {
		m_aInputSynapses.add(a_pSynapse);
	}
	
	public void AddOutputSynapse(Synapse a_pSynapse) {
		m_aOutputSynapses.add(a_pSynapse);
	}
	
	public float GetValue() {
		return m_fValue;
	}
	
	public ArrayList<Synapse> GetInputSynapses() {
		return m_aInputSynapses;
	}
	
	public ArrayList<Synapse> GetOutSynapses() {
		return m_aOutputSynapses;
	}
}
