public class IrisDataPoint extends DataPoint {
	public float m_fSepalLength = 0.0f;
	public float m_fSepalWidth = 0.0f;
	public float m_fPetalLength = 0.0f;
	public float m_fPetalWidth = 0.0f;
	public String m_sSpecies = "";
	
	public void PrintDataSet() {
		System.out.format("%-15f %-15f %-15f %-15f %s\n", m_fSepalLength, m_fSepalWidth, m_fPetalLength, m_fPetalWidth, m_sSpecies);
	}
}
