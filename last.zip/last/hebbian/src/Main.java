

public class Main {
	public static void main(String[] args) {
		//Get the datagatherer
		DataGatherer pDataGatherer = new IrisDataGatherer();
		pDataGatherer.Init();
		
		int TotalCorrect = 0;
		int TotalIncorrect = 0;
		
		for(int k=0; k < 500000; k++) {
			IrishNeuralNetwork pNetwork = new IrishNeuralNetwork();
			pNetwork.Init(0);
			for(int i=0; i < 120; i++) {
				DataPoint CurrentData = pDataGatherer.GetDataPoint();
				pNetwork.Run(CurrentData);
				pNetwork.Learn(CurrentData);
			}
			
			for(int i=0; i < 30; i++) {
				DataPoint CurrentData = pDataGatherer.GetDataPoint();
				pNetwork.Run(CurrentData);
				pNetwork.Check(CurrentData);
			}
			
			TotalCorrect += pNetwork.GetCorrect();
			TotalIncorrect += pNetwork.GetInCorrect();
			pDataGatherer.ResetDataPoint();
		}
		
		System.out.format("Correct (Perc): %-15f Incorrect: %-15f\n", TotalCorrect/(float)(TotalCorrect+TotalIncorrect), TotalIncorrect/(float)(TotalCorrect+TotalIncorrect));
		
		
	}
}
