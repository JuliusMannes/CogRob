
public abstract class DataPoint {

}
