public class IrisDataPoint extends DataPoint {
	public float m_fSepalLength = 0.0f;
	public float m_fSepalWidth = 0.0f;
	public float m_fPetalLength = 0.0f;
	public float m_fPetalWidth = 0.0f;
	public String m_sSpecies = "";
}
