import java.util.ArrayList;


public class Synapse {
	//Variables
	public final float m_fe = 2.71828182f;
	public final float m_fLearn = 0.02f;
	private Neuron m_pInputNeuron = null;
	private Neuron m_pOutputNeuron = null;
	private float m_fWeight = 0.0f;
	private float m_fLastFiredValue = 0.0f;
	private float m_fSigmoidX = 0.0f;
	
	public Synapse(Neuron a_pInputNeuron, Neuron a_pOutNeuron) {
		m_pInputNeuron = a_pInputNeuron;
		m_pOutputNeuron = a_pOutNeuron;
		m_fWeight = (float) (Math.random()*0.1f);
		m_pInputNeuron.AddOutputSynapse(this);
		m_pOutputNeuron.AddInputSynapse(this);
	}
	
	public void Propagates(float a_fValue) {
		//m_fLastFiredValue = a_fValue * GetWeight();
		m_fLastFiredValue = (float)(1.0f/(1.0f+Math.pow(m_fe,-a_fValue*m_fWeight)));
		m_pOutputNeuron.ReceiveInput(m_fLastFiredValue);
	}
	
	public void Reset() {
		m_fLastFiredValue = 0.0f;
	}
	
	public void Learn(float a_iModifier) {
		//Learning rule
		m_fWeight += m_fLearn * m_fLastFiredValue * m_fLastFiredValue * a_iModifier;
		
		//Loop through upper connections
		ArrayList<Synapse> InputSynapses = m_pInputNeuron.GetInputSynapses();
		for(int i=0; i < InputSynapses.size(); i++) {
			InputSynapses.get(i).Learn(a_iModifier);
		}
	}
	
	public void Learn2(float a_fWeightChange) {
		m_fSigmoidX += a_fWeightChange;
	}
	
	public float GetWeight() {
		return m_fWeight;
		//return (float)(1.0f/(1.0f+Math.pow(m_fe,-m_fWeight)));
	}
	
	public void SetWeight(float a_fWeight) {
		m_fWeight = a_fWeight;
	}
	
	public float GetLastFired() {
		return m_fLastFiredValue;
	}
	
	public Neuron GetInputNeuron() {
		return m_pInputNeuron;
	}
}
