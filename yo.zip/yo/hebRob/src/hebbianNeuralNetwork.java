
public class hebbianNeuralNetwork {

}
